package csc372mod3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class MenuHandler	{
	
	private JTextArea textBox;
	private Random random;
	
	public MenuHandler(JTextArea textBox)	{
		this.textBox = textBox;
		this.random = new Random();
	}
	
	public JMenuBar createMenuBar()	{
		JMenuBar menuBar = new JMenuBar();
		
		JMenu menu = new JMenu("Options");
		JMenuItem dateTimeItem = new JMenuItem("Print Date & Time");
		JMenuItem saveToFileItem = new JMenuItem("Save to File");
		JMenuItem changeColorItem = new JMenuItem("Change Background Color");
		JMenuItem exitItem = new JMenuItem("Exit");
		
		dateTimeItem.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				printDateTime();
			}
		});
		saveToFileItem.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				saveToFile();
			}
		});
		changeColorItem.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				changeBackgroundColor();
			}
		});
		exitItem.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				System.exit(0);
			}
		});
		
		menu.add(dateTimeItem);
		menu.add(saveToFileItem);
		menu.add(changeColorItem);
		menu.add(exitItem);
		
		menuBar.add(menu);
		return menuBar;
	}
	
	private void printDateTime()	{
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy   hh:mm a");
		String formattedDateTime = now.format(formatter);
		textBox.setText("Current Date & Time:  " + formattedDateTime);
	}
	
	private void saveToFile()	{
		try(FileWriter writer = new FileWriter("log.txt"))	{
			writer.write(textBox.getText());
		} catch(IOException e)	{
			textBox.setText("Error saving to file: " + e.getMessage());
		}
	}
	
	private void changeBackgroundColor()	{
		int hue = random.nextInt(101) + 60;
		textBox.setBackground(new Color(hue, 255, hue));
		textBox.append("\nBackground Color (Hue: " + hue + ")");
	}
}