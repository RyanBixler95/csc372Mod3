package csc372mod3;

import javax.swing.*;
import java.awt.*;

public class UserInterfaceMain	{

	public static void main(String[] args)	{
		SwingUtilities.invokeLater(() ->	{
			JFrame frame = new JFrame("User Interface");
			JTextArea textBox = new JTextArea();
			
			MenuHandler menuHandler = new MenuHandler(textBox);
			JMenuBar menuBar = menuHandler.createMenuBar();
			
			frame.setJMenuBar(menuBar);
			frame.add(new JScrollPane(textBox), BorderLayout.CENTER);
			
			frame.setSize(400, 300);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
		});
	}
}